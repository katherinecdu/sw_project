import setuptools

setuptools.setup(
    scripts=['hw1.py','blosum62.txt','input.txt'],
    name="sw_project",
    version="0.0.1"
)
