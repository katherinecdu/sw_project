import setuptools

setuptools.setup(
scripts=['src/sw_project/hw1.py']
)
