import setuptools

setuptools.setup(
    scripts=['hw1.py'],
    name="sw_project",
    version="0.0.1"
)
